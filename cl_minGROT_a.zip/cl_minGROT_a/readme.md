----Purpose----
This is a clientside cheat for the game Garrys Mod. It has aimbot, wallhacks and other
features that can be used for a player's desires.

----Reason----
I was bored and wanted to make a simple script using GLua. Also, I found it
interesting to learn about cheats and how they operate.

----Inner Workings----
It uses hooks and functions to draw tracers, halos and general statistics
for the player to utilize in-game.

---Misc.---
Note: Although I made a cheating script, I discourage you to use this in a public server 
with people who are simply enjoying the game.